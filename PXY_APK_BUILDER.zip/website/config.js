window.PXY_CONFIG = { API_BASE: '' }; // Set to your deployed backend URL, e.g. https://your-backend.example.com

const $=id=>document.getElementById(id);
const api=(window.PXY_CONFIG?.API_BASE||'').replace(/\/$/,'');
function status(s,p){$('status').textContent=s;if(p!==undefined)$('progress').style.width=p+'%'}
$('build').addEventListener('click',async()=>{
 const source=$('source').files[0], icon=$('icon').files[0], name=$('appName').value.trim(), pkg=$('packageName').value.trim();
 $('download').style.display='none';
 if(!source){status('Pilih file HTML atau ZIP terlebih dahulu.');return}
 if(!name){status('Masukkan nama aplikasi.');return}
 if(!/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(pkg)){status('Package name tidak valid. Contoh: com.pxy.aplikasi');return}
 if(!/\.(html?|zip)$/i.test(source.name)){status('Format file harus HTML atau ZIP.');return}
 const fd=new FormData();fd.append('source',source);fd.append('appName',name);fd.append('packageName',pkg);if(icon)fd.append('icon',icon);
 $('build').disabled=true;status('Mengunggah file…',8);
 try{
  const r=await fetch(api+'/api/build',{method:'POST',body:fd});const data=await r.json();
  if(!r.ok)throw new Error(data.error||'Upload gagal');
  const id=data.jobId;let done=false;
  while(!done){
   await new Promise(res=>setTimeout(res,2500));
   const sr=await fetch(api+'/api/jobs/'+encodeURIComponent(id));const st=await sr.json();
   status(st.message||st.status,st.status==='queued'?15:st.status==='building'?55:st.status==='done'?100:35);
   if(st.status==='done'){const link=api+st.downloadUrl;$('download').href=link;$('download').style.display='block';status('Build berhasil! Tekan DOWNLOAD APK.',100);done=true}
   if(st.status==='error')throw new Error(st.error||'Build gagal');
  }
 }catch(e){status('Gagal: '+e.message+'\\nPeriksa apakah backend sudah aktif dan Android SDK terpasang.')}
 finally{$('build').disabled=false}
});

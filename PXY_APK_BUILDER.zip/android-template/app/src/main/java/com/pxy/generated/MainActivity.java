package com.pxy.generated;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView web = new WebView(this);
        web.setBackgroundColor(0xFF090909);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/site/index.html");
    }
    @Override public void onBackPressed() {
        WebView web = findViewById(android.R.id.content).getChildCount() > 0
            ? (WebView)((android.view.ViewGroup)findViewById(android.R.id.content)).getChildAt(0) : null;
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}

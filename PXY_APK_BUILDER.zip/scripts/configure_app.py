#!/usr/bin/env python3
import os, re, shutil, sys, html
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
project=Path('android-template')
app_name=os.environ.get('APP_NAME','PXY App').strip()[:40] or 'PXY App'
package=os.environ.get('PACKAGE_NAME','com.pxy.generated').strip()
if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+', package):
    raise SystemExit('Invalid package name. Use e.g. com.pxy.myapp')
# source: input/index.html or input/source.zip
site=project/'app/src/main/assets/site'
site.mkdir(parents=True,exist_ok=True)
source_zip=Path('input/source.zip')
if Path('input/index.html').is_file():
    for item in Path('input').iterdir():
        if item.name in ('icon.png','source.zip','extracted'): continue
        dest=site/item.name
        if item.is_dir():
            if dest.exists(): shutil.rmtree(dest)
            shutil.copytree(item,dest)
        elif item.name.lower().endswith(('.html','.htm','.css','.js','.json','.png','.jpg','.jpeg','.webp','.svg','.gif','.mp4','.mp3','.woff','.woff2','.ttf','.ico')):
            shutil.copy2(item,dest)
elif source_zip.is_file():
    import zipfile
    extract=Path('input/extracted')
    if extract.exists(): shutil.rmtree(extract)
    extract.mkdir(parents=True)
    with zipfile.ZipFile(source_zip) as z:
        for member in z.infolist():
            name=member.filename.replace('\\\\','/')
            if name.startswith('/') or '..' in Path(name).parts:
                raise SystemExit('Unsafe ZIP path')
        z.extractall(extract)
    base=extract
    if not (base/'index.html').exists():
        children=list(base.iterdir())
        if len(children)==1 and children[0].is_dir(): base=children[0]
    if not (base/'index.html').is_file(): raise SystemExit('index.html not found in ZIP')
    for item in base.iterdir():
        dest=site/item.name
        if item.is_dir():
            if dest.exists(): shutil.rmtree(dest)
            shutil.copytree(item,dest)
        else: shutil.copy2(item,dest)
else:
    raise SystemExit('Add input/index.html (plus assets) or input/source.zip')
if not (site/'index.html').is_file(): raise SystemExit('index.html missing from packaged website')
# package / namespace and activity path
old='com.pxy.generated'
gradle=project/'app/build.gradle'
text=gradle.read_text().replace(old,package)
gradle.write_text(text)
manifest=project/'app/src/main/AndroidManifest.xml'
text=manifest.read_text().replace(old+'.MainActivity',package+'.MainActivity').replace('PXY App',html.escape(app_name, quote=True))
manifest.write_text(text)
java_old=project/'app/src/main/java/com/pxy/generated/MainActivity.java'
java_text=java_old.read_text().replace(old,package)
java_new=project/'app/src/main/java'/Path(package.replace('.','/'))/'MainActivity.java'
java_new.parent.mkdir(parents=True,exist_ok=True)
java_new.write_text(java_text)
if java_old.exists(): java_old.unlink()
# optional custom PNG logo, resized to standard launcher densities
icon=Path('input/icon.png')
if icon.is_file():
    try:
        im=Image.open(icon).convert('RGBA')
    except Exception as e:
        raise SystemExit('Could not read input/icon.png: '+str(e))
    for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
        out=project/f'app/src/main/res/mipmap-{density}/ic_launcher.png'
        out.parent.mkdir(parents=True,exist_ok=True)
        im2=ImageOps.contain(im,(size,size),Image.Resampling.LANCZOS)
        canvas=Image.new('RGBA',(size,size),(10,10,10,255))
        canvas.alpha_composite(im2,((size-im2.width)//2,(size-im2.height)//2))
        canvas.save(out)
print('Configured app:', app_name, package)

require('dotenv').config();
const express=require('express'),cors=require('cors'),multer=require('multer'),AdmZip=require('adm-zip');
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),{spawn}=require('child_process');
const app=express();app.use(cors());app.use(express.json());
const PORT=Number(process.env.PORT||3000), MAX_MB=Number(process.env.MAX_UPLOAD_MB||20), TIMEOUT=Number(process.env.BUILD_TIMEOUT_MS||240000);
const ROOT=path.resolve(__dirname,'..'), TEMPLATE=path.join(ROOT,'android-template'), JOBROOT=path.join(os.tmpdir(),'pxy-apk-jobs');
fs.mkdirSync(JOBROOT,{recursive:true});
const jobs=new Map();
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:MAX_MB*1024*1024,files:2}});
app.get('/api/health',(req,res)=>res.json({ok:true,service:'PXY APK BUILDER',note:'Android SDK and Java 17 must be installed'}));
function safeName(s){return String(s||'PXY App').replace(/[^a-zA-Z0-9 _.-]/g,'').trim().slice(0,40)||'PXY App'}
function validPackage(s){return /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(s)&&s.length<=120}
function extractSource(file,dest){
 const ext=path.extname(file.originalname).toLowerCase();let html;
 if(ext==='.html'||ext==='.htm'){html=file.buffer;fs.writeFileSync(path.join(dest,'index.html'),html);return}
 if(ext!=='.zip')throw Error('File harus HTML atau ZIP');
 const zip=new AdmZip(file.buffer), entries=zip.getEntries();
 if(entries.length>500)throw Error('ZIP berisi terlalu banyak file (maksimum 500).');
 let total=0;
 for(const e of entries){
  const n=e.entryName.replace(/\\/g,'/');
  if(n.startsWith('/')||n.split('/').includes('..'))throw Error('ZIP memiliki path yang tidak aman.');
  if(!e.isDirectory){total+=e.header.size||0;if(total>50*1024*1024)throw Error('Isi ZIP maksimal 50 MB.')}
 }
 const temp=path.join(dest,'unzipped');fs.mkdirSync(temp);
 zip.extractAllTo(temp,true);
 let base=temp;
 if(!fs.existsSync(path.join(base,'index.html'))){
  const children=fs.readdirSync(base);
  if(children.length===1&&fs.statSync(path.join(base,children[0])).isDirectory())base=path.join(base,children[0]);
 }
 if(!fs.existsSync(path.join(base,'index.html')))throw Error('index.html tidak ditemukan di ZIP.');
 for(const item of fs.readdirSync(base)){const from=path.join(base,item),to=path.join(dest,item);if(item==='unzipped')continue;fs.cpSync(from,to,{recursive:true})}
 fs.rmSync(temp,{recursive:true,force:true});
}
function run(cmd,args,opts,timeout){return new Promise((resolve,reject)=>{
 const child=spawn(cmd,args,{...opts,stdio:['ignore','pipe','pipe']});let out='',err='',timed=false;
 child.stdout.on('data',d=>out+=d.toString());child.stderr.on('data',d=>err+=d.toString());
 const timer=setTimeout(()=>{timed=true;child.kill('SIGKILL')},timeout);
 child.on('error',e=>{clearTimeout(timer);reject(e)});
 child.on('close',code=>{clearTimeout(timer);if(code===0&&!timed)resolve(out);else reject(Error((timed?'Build timeout. ':'Gradle exit '+code+'. ')+(err||out).slice(-3500)))});
})}
app.post('/api/build',upload.fields([{name:'source',maxCount:1},{name:'icon',maxCount:1}]),async(req,res)=>{
 const file=req.files?.source?.[0];if(!file)return res.status(400).json({error:'File sumber wajib diunggah.'});
 const name=safeName(req.body.appName),pkg=String(req.body.packageName||'');
 if(!validPackage(pkg))return res.status(400).json({error:'Package name tidak valid.'});
 const id=crypto.randomUUID(),dir=path.join(JOBROOT,id);fs.mkdirSync(dir,{recursive:true});
 const job={id,status:'queued',message:'Menyiapkan proyek…',dir};jobs.set(id,job);res.status(202).json({jobId:id});
 (async()=>{
 try{
  fs.cpSync(TEMPLATE,path.join(dir,'project'),{recursive:true});const project=path.join(dir,'project');
  const assets=path.join(project,'app/src/main/assets/site');fs.mkdirSync(assets,{recursive:true});
  extractSource(file,assets);
  const javaDir=path.join(project,'app/src/main/java',...pkg.split('.'));fs.mkdirSync(javaDir,{recursive:true});
  const java=fs.readFileSync(path.join(TEMPLATE,'app/src/main/java/com/pxy/generated/MainActivity.java'),'utf8');
  fs.writeFileSync(path.join(javaDir,'MainActivity.java'),java.replaceAll('com.pxy.generated',pkg));
  const manifest=path.join(project,'app/src/main/AndroidManifest.xml');
  fs.writeFileSync(manifest,fs.readFileSync(manifest,'utf8').replaceAll('com.pxy.generated',pkg).replace('PXY App',name.replace(/&/g,'&amp;').replace(/"/g,'&quot;')));
  fs.writeFileSync(path.join(project,'app/build.gradle'),fs.readFileSync(path.join(project,'app/build.gradle'),'utf8').replaceAll('com.pxy.generated',pkg));
  const icon=req.files?.icon?.[0];
  if(icon){
   if(icon.mimetype!=='image/png')throw Error('Logo launcher harus PNG. Ubah logo ke PNG lalu upload lagi.');
   const iconDir=path.join(project,'app/src/main/res');
   // Use a square PNG logo as the launcher icon at every standard density.
   // The source is copied to density folders; Android scales it as needed.
   for(const density of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']){
    const out=path.join(iconDir,'mipmap-'+density,'ic_launcher.png');
    fs.mkdirSync(path.dirname(out),{recursive:true});
    fs.writeFileSync(out,icon.buffer);
   }
  }
  job.status='building';job.message='Gradle sedang mengompilasi APK…';
  await run('gradle',['--no-daemon','assembleDebug'],{cwd:project,env:{...process.env,ANDROID_HOME:process.env.ANDROID_HOME||process.env.ANDROID_SDK_ROOT||''}},TIMEOUT);
  const apk=path.join(project,'app/build/outputs/apk/debug/app-debug.apk');if(!fs.existsSync(apk))throw Error('APK output tidak ditemukan.');
  job.apk=apk;job.status='done';job.message='Build selesai.';
 }catch(e){job.status='error';job.error=e.message;job.message='Build gagal.'}
 })();
});
app.get('/api/jobs/:id',(req,res)=>{const j=jobs.get(req.params.id);if(!j)return res.status(404).json({error:'Job tidak ditemukan.'});res.json({jobId:j.id,status:j.status,message:j.message,error:j.error,downloadUrl:j.status==='done'?'/api/jobs/'+j.id+'/apk':undefined})});
app.get('/api/jobs/:id/apk',(req,res)=>{const j=jobs.get(req.params.id);if(!j||j.status!=='done'||!j.apk||!fs.existsSync(j.apk))return res.status(404).json({error:'APK belum tersedia.'});res.download(j.apk,'pxy-app-debug.apk')});
app.use((err,req,res,next)=>res.status(err.code==='LIMIT_FILE_SIZE'?413:400).json({error:err.message||'Request tidak valid.'}));
app.listen(PORT,()=>console.log(`PXY APK BUILDER listening on ${PORT}`));

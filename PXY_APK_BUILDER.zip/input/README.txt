Place your website source here before running GitHub Actions: input/index.html or input/source.zip (ZIP must contain index.html).

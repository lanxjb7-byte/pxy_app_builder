# PXY APK BUILDER

Website + Node.js backend that packages an uploaded `index.html` or `.zip` into a real Android WebView APK.

## Important
- The website form accepts an app name and optional PNG launcher logo, and the backend applies them to the APK. This is a starter project, not a hosted service. You must deploy the backend somewhere with Java 17, Android SDK, and enough disk/RAM to run Gradle.
- Free hosting often sleeps, limits execution time, or does not allow Android SDK builds. The most practical free workflow is GitHub Actions (included) to build the APK; a permanently available public upload-to-APK server may not be free.
- The generated APK is a basic WebView wrapper. It does not convert arbitrary HTML into native Android UI.
- Only upload files you own or have permission to package. Uploaded HTML runs inside a WebView; don't expose this service publicly without authentication, upload limits, rate limiting, and isolation.

## Project layout
- `website/` — static frontend
- `server/` — Express backend for upload + build
- `android-template/` — Android WebView app template
- `.github/workflows/build-apk.yml` — free GitHub Actions build path

## Run backend locally (Linux/macOS or Linux VPS)
Requirements: Node.js 20+, JDK 17, Android SDK command-line tools, Android platform 35, build-tools 35.0.0, Gradle 8.9.

1. Install Android SDK and set `ANDROID_HOME` (or `ANDROID_SDK_ROOT`).
2. Install packages:
   ```bash
   cd server
   npm install
   ```
3. Copy `server/.env.example` to `server/.env` and set `PORT` if needed.
4. Start:
   ```bash
   npm start
   ```
5. Open `http://localhost:3000`.

The backend expects the Android SDK to be installed and accessible. First build can take several minutes.

## Deploy the website
Host the `website/` folder on Netlify, Cloudflare Pages, or GitHub Pages. Set `API_BASE` in `website/config.js` to your backend URL. Static hosting alone cannot compile APKs.

## Deploy the backend
Use a Linux VPS/container that permits Android SDK + Java builds. Set:
- `PORT` — listening port
- `MAX_UPLOAD_MB` — max upload size (default 20)
- `BUILD_TIMEOUT_MS` — build timeout (default 240000)
- `API_BASE` is configured in frontend `website/config.js`

A typical free app host may not have sufficient memory, persistent disk, or execution time. Do not assume a free host will successfully build APKs.

## GitHub Actions build (free quota subject to GitHub limits)
1. Create a GitHub repository and upload this project.
2. In the repo, add your HTML file as `input/index.html`, OR a ZIP containing `index.html` at its root (or under a single top-level folder).
4. Open **Actions** → **PXY Build APK** → **Run workflow**. Enter the app name and unique package name in the workflow inputs.
5. Download the `pxy-debug-apk` artifact from the completed workflow run.
6. The output is a debug APK, suitable for testing. Android may warn that it is from an unknown source.

## Security notes before public deployment
This sample includes file size checks, ZIP path checks, random job directories, and a basic in-memory job status map. It is not production hardened. Add authentication, quotas, persistent job storage, malware scanning, per-job sandboxing, and cleanup before exposing it to the public internet.
